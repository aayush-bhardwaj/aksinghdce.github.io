<!-- Tufts VUE 3.2.2 concept-map (openstack.vue) 2015-08-21 -->
<!-- Tufts VUE: http://vue.tufts.edu/ -->
<!-- Do Not Remove: VUE mapping @version(1.1) jar:file:/C:/Program%20Files%20(x86)/VUE/VUE.jar!/tufts/vue/resources/lw_mapping_1_1.xml -->
<!-- Do Not Remove: Saved date Fri Aug 21 16:13:18 IST 2015 by siamitku on platform Windows 7 6.1 in JVM 1.7.0_21-b11 -->
<!-- Do Not Remove: Saving version @(#)VUE: built May 23 2013 at 2146 by tomadm on Linux 2.6.18-348.2.1.el5 i386 JVM 1.7.0_21-b11(bits=32) -->
<?xml version="1.0" encoding="US-ASCII"?>
<LW-MAP xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
    xsi:noNamespaceSchemaLocation="none" ID="0" label="openstack.vue"
    created="1440147222243" x="0.0" y="0.0" width="1.4E-45"
    height="1.4E-45" strokeWidth="0.0" autoSized="false">
    <resource referenceCreated="1440153798680"
        spec="C:\Users\siamitku\Documents\VUE\openstack.vue" type="1" xsi:type="URLResource">
        <title>openstack.vue</title>
        <property key="File" value="C:\Users\siamitku\Documents\VUE\openstack.vue"/>
    </resource>
    <fillColor>#FFFFFF</fillColor>
    <strokeColor>#404040</strokeColor>
    <textColor>#000000</textColor>
    <font>SansSerif-plain-14</font>
    <URIString>http://vue.tufts.edu/rdf/resource/4fdb081d10b3d16600b3589d067e6966</URIString>
    <child ID="6" label="OpenStack" layerID="1" created="1440150014115"
        x="519.0" y="317.0" width="71.0" height="23.0" strokeWidth="1.0"
        autoSized="true" xsi:type="node">
        <fillColor>#F1A83E</fillColor>
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <URIString>http://vue.tufts.edu/rdf/resource/4fdb081f10b3d16600b3589dcfba400c</URIString>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="10" label="quickstart" layerID="1"
        created="1440150518996" x="621.5" y="282.5" width="64.0"
        height="23.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
        <fillColor>#F1A83E</fillColor>
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <URIString>http://vue.tufts.edu/rdf/resource/4fdb082110b3d16600b3589d0ff0e5b1</URIString>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="11" layerID="1" created="1440150518999" x="583.8533"
        y="303.0993" width="42.60077" height="15.497284"
        strokeWidth="1.0" autoSized="false" controlCount="0"
        arrowState="2" xsi:type="link">
        <strokeColor>#404040</strokeColor>
        <textColor>#404040</textColor>
        <font>Arial-plain-11</font>
        <URIString>http://vue.tufts.edu/rdf/resource/4fdb082210b3d16600b3589dfd6fdd89</URIString>
        <point1 x="584.35333" y="318.0966"/>
        <point2 x="625.9541" y="303.5993"/>
        <ID1 xsi:type="node">6</ID1>
        <ID2 xsi:type="node">10</ID2>
    </child>
    <child ID="15" label="download virtualbox" layerID="1"
        created="1440153578723" x="732.5" y="247.5" width="119.0"
        height="23.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
        <fillColor>#F1A83E</fillColor>
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <URIString>http://vue.tufts.edu/rdf/resource/4fdb082410b3d16600b3589dcee4339c</URIString>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="16" layerID="1" created="1440153578726" x="682.7765"
        y="270.0" width="64.21625" height="16.97525" strokeWidth="1.0"
        autoSized="false" controlCount="0" arrowState="2" xsi:type="link">
        <strokeColor>#404040</strokeColor>
        <textColor>#404040</textColor>
        <font>Arial-plain-11</font>
        <URIString>http://vue.tufts.edu/rdf/resource/4fdb082510b3d16600b3589d72b2d15e</URIString>
        <point1 x="683.27655" y="286.47525"/>
        <point2 x="746.4928" y="270.5"/>
        <ID1 xsi:type="node">10</ID1>
        <ID2 xsi:type="node">15</ID2>
    </child>
    <child ID="17" label="install ubuntu server" layerID="1"
        created="1440153603327" x="732.5" y="272.5" width="122.0"
        height="23.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
        <fillColor>#F1A83E</fillColor>
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <URIString>http://vue.tufts.edu/rdf/resource/4fdb082810b3d16600b3589d13b1c7f0</URIString>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="18" layerID="1" created="1440153603330" x="684.8435"
        y="287.81653" width="48.725037" height="4.4089355"
        strokeWidth="1.0" autoSized="false" controlCount="0"
        arrowState="2" xsi:type="link">
        <strokeColor>#404040</strokeColor>
        <textColor>#404040</textColor>
        <font>Arial-plain-11</font>
        <URIString>http://vue.tufts.edu/rdf/resource/4fdb082a10b3d16600b3589d2fb37a94</URIString>
        <point1 x="685.34357" y="291.72546"/>
        <point2 x="733.0686" y="288.31653"/>
        <ID1 xsi:type="node">10</ID1>
        <ID2 xsi:type="node">17</ID2>
    </child>
    <child ID="19" label="install openstack on ubuntu" layerID="1"
        created="1440153619162" x="731.5" y="297.5" width="190.0"
        height="27.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
        <notes>http://askubuntu.com/questions/459590/open-stack-installation-on-ubuntu-14-04 </notes>
        <fillColor>#F1A83E</fillColor>
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <URIString>http://vue.tufts.edu/rdf/resource/4fdb082c10b3d16600b3589d11298ff5</URIString>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="20" layerID="1" created="1440153619166" x="684.6743"
        y="296.6125" width="49.2912" height="5.745392" strokeWidth="1.0"
        autoSized="false" controlCount="0" arrowState="2" xsi:type="link">
        <strokeColor>#404040</strokeColor>
        <textColor>#404040</textColor>
        <font>Arial-plain-11</font>
        <URIString>http://vue.tufts.edu/rdf/resource/4fdb082e10b3d16600b3589d3692f522</URIString>
        <point1 x="685.1744" y="297.1125"/>
        <point2 x="733.4656" y="301.85788"/>
        <ID1 xsi:type="node">10</ID1>
        <ID2 xsi:type="node">19</ID2>
    </child>
    <layer ID="1" label="Layer 1" created="1440147222427" x="0.0"
        y="0.0" width="1.4E-45" height="1.4E-45" strokeWidth="0.0" autoSized="false">
        <URIString>http://vue.tufts.edu/rdf/resource/4fdb082f10b3d16600b3589d280727a4</URIString>
    </layer>
    <userZoom>1.0</userZoom>
    <userOrigin x="-14.0" y="-14.0"/>
    <presentationBackground>#202020</presentationBackground>
    <PathwayList currentPathway="0" revealerIndex="-1">
        <pathway ID="0" label="Untitled Pathway" created="1440147222240"
            x="0.0" y="0.0" width="1.4E-45" height="1.4E-45"
            strokeWidth="0.0" autoSized="false" currentIndex="-1" open="true">
            <strokeColor>#B3993333</strokeColor>
            <textColor>#000000</textColor>
            <font>SansSerif-plain-14</font>
            <URIString>http://vue.tufts.edu/rdf/resource/4fdb083110b3d16600b3589d01d1114f</URIString>
            <masterSlide ID="2" created="1440147222481" x="0.0" y="0.0"
                width="800.0" height="600.0" locked="true"
                strokeWidth="0.0" autoSized="false">
                <fillColor>#000000</fillColor>
                <strokeColor>#404040</strokeColor>
                <textColor>#000000</textColor>
                <font>SansSerif-plain-14</font>
                <URIString>http://vue.tufts.edu/rdf/resource/4fdb083310b3d16600b3589d45619941</URIString>
                <titleStyle ID="3" label="Header"
                    created="1440147223785" x="335.5" y="172.5"
                    width="129.0" height="55.0" strokeWidth="0.0"
                    autoSized="true" isStyle="true" xsi:type="node">
                    <strokeColor>#404040</strokeColor>
                    <textColor>#FFFFFF</textColor>
                    <font>Gill Sans-plain-36</font>
                    <URIString>http://vue.tufts.edu/rdf/resource/4fdb083510b3d16600b3589de9edc93b</URIString>
                    <shape xsi:type="rectangle"/>
                </titleStyle>
                <textStyle ID="4" label="Slide Text"
                    created="1440147223789" x="346.5" y="281.5"
                    width="107.0" height="37.0" strokeWidth="0.0"
                    autoSized="true" isStyle="true" xsi:type="node">
                    <strokeColor>#404040</strokeColor>
                    <textColor>#FFFFFF</textColor>
                    <font>Gill Sans-plain-22</font>
                    <URIString>http://vue.tufts.edu/rdf/resource/4fdb083710b3d16600b3589d580dc336</URIString>
                    <shape xsi:type="rectangle"/>
                </textStyle>
                <linkStyle ID="5" label="Links" created="1440147223793"
                    x="373.5" y="384.0" width="53.0" height="32.0"
                    strokeWidth="0.0" autoSized="true" isStyle="true" xsi:type="node">
                    <strokeColor>#404040</strokeColor>
                    <textColor>#B3BFE3</textColor>
                    <font>Gill Sans-plain-18</font>
                    <URIString>http://vue.tufts.edu/rdf/resource/4fdb084310b3d16600b3589dcab8beec</URIString>
                    <shape xsi:type="rectangle"/>
                </linkStyle>
            </masterSlide>
        </pathway>
    </PathwayList>
    <date>2015-08-21</date>
    <modelVersion>6</modelVersion>
    <saveLocation>C:\Users\siamitku\Documents\VUE</saveLocation>
    <saveFile>C:\Users\siamitku\Documents\VUE\openstack.vue</saveFile>
</LW-MAP>
