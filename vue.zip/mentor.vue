<!-- Tufts VUE 3.2.2 concept-map (mentor.vue) 2015-08-21 -->
<!-- Tufts VUE: http://vue.tufts.edu/ -->
<!-- Do Not Remove: VUE mapping @version(1.1) jar:file:/C:/Program%20Files%20(x86)/VUE/VUE.jar!/tufts/vue/resources/lw_mapping_1_1.xml -->
<!-- Do Not Remove: Saved date Fri Aug 21 16:27:51 IST 2015 by siamitku on platform Windows 7 6.1 in JVM 1.7.0_21-b11 -->
<!-- Do Not Remove: Saving version @(#)VUE: built May 23 2013 at 2146 by tomadm on Linux 2.6.18-348.2.1.el5 i386 JVM 1.7.0_21-b11(bits=32) -->
<?xml version="1.0" encoding="US-ASCII"?>
<LW-MAP xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
    xsi:noNamespaceSchemaLocation="none" ID="0" label="mentor.vue"
    created="1440153806327" x="0.0" y="0.0" width="1.4E-45"
    height="1.4E-45" strokeWidth="0.0" autoSized="false">
    <resource referenceCreated="1440154671315"
        spec="C:\Users\siamitku\Documents\VUE\mentor.vue" type="1" xsi:type="URLResource">
        <title>mentor.vue</title>
        <property key="File" value="C:\Users\siamitku\Documents\VUE\mentor.vue"/>
    </resource>
    <fillColor>#FFFFFF</fillColor>
    <strokeColor>#404040</strokeColor>
    <textColor>#000000</textColor>
    <font>SansSerif-plain-14</font>
    <URIString>http://vue.tufts.edu/rdf/resource/4fe858d710b3d16600b3589d5cae5422</URIString>
    <child ID="7" label="personal page" layerID="1"
        created="1440153854021" x="579.5" y="278.5" width="119.0"
        height="27.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
        <notes>the content of this page can be:%nl;1. A picture of a physical notebook%nl;2. An YouTube video%nl;3. A whatsapp message%nl;4. A text note%nl;5. An image%nl;6. A voice clip%nl;%nl;Think of this as a whiteboard, which is written over by the mentor and the student alike in order to understand the concept</notes>
        <fillColor>#F1A83E</fillColor>
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <URIString>http://vue.tufts.edu/rdf/resource/4fe858da10b3d16600b3589df2082e1e</URIString>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="9" label="mentor" layerID="1" created="1440153896037"
        x="916.0" y="191.0" width="67.0" height="30.0" strokeWidth="1.0"
        autoSized="false" xsi:type="node">
        <fillColor>#F1A83E</fillColor>
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <URIString>http://vue.tufts.edu/rdf/resource/4fe858db10b3d16600b3589d9c20b90c</URIString>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="10"
        label="coaches privately&#xa;until the student has learnt&#xa;the concept"
        layerID="1" created="1440153940422" x="687.24133" y="214.53442"
        width="230.1402" height="64.46556" strokeWidth="1.0"
        autoSized="false" controlCount="0" arrowState="2" xsi:type="link">
        <strokeColor>#404040</strokeColor>
        <textColor>#404040</textColor>
        <font>Arial-plain-11</font>
        <URIString>http://vue.tufts.edu/rdf/resource/4fe858dc10b3d16600b3589d0d87139d</URIString>
        <point1 x="916.8815" y="215.03444"/>
        <point2 x="687.7413" y="278.5"/>
        <ID1 xsi:type="node">9</ID1>
        <ID2 xsi:type="node">7</ID2>
    </child>
    <child ID="13" label="public page" layerID="1"
        created="1440154093325" x="565.0" y="89.0" width="103.0"
        height="27.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
        <notes>Contents of this page are derived out of the personal page.%nl;%nl;Enough data is provided to make the concept easily graspable.</notes>
        <fillColor>#F1A83E</fillColor>
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <URIString>http://vue.tufts.edu/rdf/resource/4fe858dd10b3d16600b3589d1db4e091</URIString>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="14"
        label="after the student understood&#xa;the concept&#xa;the concept goes to public page"
        layerID="1" created="1440154104994" x="550.25" y="115.49951"
        width="155.0" height="163.50049" strokeWidth="1.0"
        autoSized="false" controlCount="0" arrowState="2" xsi:type="link">
        <strokeColor>#404040</strokeColor>
        <textColor>#404040</textColor>
        <font>Arial-plain-11</font>
        <URIString>http://vue.tufts.edu/rdf/resource/4fe858df10b3d16600b3589de7b3264a</URIString>
        <point1 x="637.3971" y="278.5"/>
        <point2 x="618.10284" y="115.99951"/>
        <ID1 xsi:type="node">7</ID1>
        <ID2 xsi:type="node">13</ID2>
    </child>
    <child ID="15" label="student" layerID="1" created="1440154182218"
        x="347.0" y="368.0" width="77.0" height="23.0" strokeWidth="1.0"
        autoSized="false" xsi:type="node">
        <fillColor>#F1A83E</fillColor>
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <URIString>http://vue.tufts.edu/rdf/resource/4fe858e010b3d16600b3589dd64dd670</URIString>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="16" label="requests mentorship&#xa;on a particular topic"
        layerID="1" created="1440154192805" x="416.53943" y="305.0"
        width="183.84918" height="64.11359" strokeWidth="1.0"
        autoSized="false" controlCount="0" arrowState="2" xsi:type="link">
        <strokeColor>#404040</strokeColor>
        <textColor>#404040</textColor>
        <font>Arial-plain-11</font>
        <URIString>http://vue.tufts.edu/rdf/resource/4fe858e010b3d16600b3589d413c975a</URIString>
        <point1 x="417.03943" y="368.6136"/>
        <point2 x="599.8886" y="305.5"/>
        <ID1 xsi:type="node">15</ID1>
        <ID2 xsi:type="node">7</ID2>
    </child>
    <child ID="17"
        label="github branches can be used to create the personal page. The public page &#xa;      can be the github.io page"
        layerID="1" created="1440154563119" x="613.0" y="389.0"
        width="150.0" height="78.0" strokeWidth="0.0" autoSized="false" xsi:type="text">
        <strokeColor>#404040</strokeColor>
        <textColor>#000000</textColor>
        <font>SansSerif-plain-14</font>
        <URIString>http://vue.tufts.edu/rdf/resource/4fe858e110b3d16600b3589ddbb58691</URIString>
        <richText>&lt;html&gt;
  &lt;head style="color: #000000" color="#000000"&gt;
    &lt;style type="text/css"&gt;
      &lt;!--
        body { color: #000000; margin-left: 0px; margin-right: 0px; font-family: Arial; font-size: 12; margin-bottom: 0px; margin-top: 0px }
        ol { margin-left: 30; font-family: Arial; list-style-position: outside; vertical-align: middle; font-size: 12; margin-top: 6 }
        p { color: #000000; margin-left: 0; margin-right: 0; margin-bottom: 0; margin-top: 0 }
        ul { margin-left: 30; font-family: Arial; list-style-position: outside; vertical-align: middle; font-size: 12; margin-top: 6 }
      --&gt;
    &lt;/style&gt;
    
  &lt;/head&gt;
  &lt;body&gt;
    &lt;p style="color: #000000" color="#000000"&gt;
      github branches can be used to create the personal page. The public page 
      can be the github.io page
    &lt;/p&gt;
  &lt;/body&gt;
&lt;/html&gt;
</richText>
        <label>github branches can be used to create the personal page. The public page 
      can be the github.io page</label>
    </child>
    <child ID="19" label="how to!!" layerID="1" created="1440154627178"
        x="639.40625" y="305.0" width="39.0" height="84.5"
        strokeWidth="1.0" autoSized="false" controlCount="0"
        arrowState="2" xsi:type="link">
        <strokeColor>#404040</strokeColor>
        <textColor>#404040</textColor>
        <font>Arial-plain-11</font>
        <URIString>http://vue.tufts.edu/rdf/resource/4fe858e410b3d16600b3589d02a77f99</URIString>
        <point1 x="673.94855" y="389.0"/>
        <point2 x="643.86395" y="305.5"/>
        <ID1 xsi:type="text">17</ID1>
        <ID2 xsi:type="node">7</ID2>
    </child>
    <layer ID="1" label="Layer 1" created="1440153806328" x="0.0"
        y="0.0" width="1.4E-45" height="1.4E-45" strokeWidth="0.0" autoSized="false">
        <URIString>http://vue.tufts.edu/rdf/resource/4fe858e510b3d16600b3589d62f40b84</URIString>
    </layer>
    <userZoom>1.0</userZoom>
    <userOrigin x="-14.0" y="-14.0"/>
    <presentationBackground>#202020</presentationBackground>
    <PathwayList currentPathway="0" revealerIndex="-1">
        <pathway ID="0" label="Untitled Pathway" created="1440153806327"
            x="0.0" y="0.0" width="1.4E-45" height="1.4E-45"
            strokeWidth="0.0" autoSized="false" currentIndex="-1" open="true">
            <strokeColor>#B3CC33CC</strokeColor>
            <textColor>#000000</textColor>
            <font>SansSerif-plain-14</font>
            <URIString>http://vue.tufts.edu/rdf/resource/4fe858e910b3d16600b3589d70648cfe</URIString>
            <masterSlide ID="2" created="1440153806364" x="0.0" y="0.0"
                width="800.0" height="600.0" locked="true"
                strokeWidth="0.0" autoSized="false">
                <fillColor>#000000</fillColor>
                <strokeColor>#404040</strokeColor>
                <textColor>#000000</textColor>
                <font>SansSerif-plain-14</font>
                <URIString>http://vue.tufts.edu/rdf/resource/4fe858ea10b3d16600b3589d3c9c8339</URIString>
                <titleStyle ID="3" label="Header"
                    created="1440153806412" x="335.5" y="172.5"
                    width="129.0" height="55.0" strokeWidth="0.0"
                    autoSized="true" isStyle="true" xsi:type="node">
                    <strokeColor>#404040</strokeColor>
                    <textColor>#FFFFFF</textColor>
                    <font>Gill Sans-plain-36</font>
                    <URIString>http://vue.tufts.edu/rdf/resource/4fe858ea10b3d16600b3589d882435af</URIString>
                    <shape xsi:type="rectangle"/>
                </titleStyle>
                <textStyle ID="4" label="Slide Text"
                    created="1440153806414" x="346.5" y="281.5"
                    width="107.0" height="37.0" strokeWidth="0.0"
                    autoSized="true" isStyle="true" xsi:type="node">
                    <strokeColor>#404040</strokeColor>
                    <textColor>#FFFFFF</textColor>
                    <font>Gill Sans-plain-22</font>
                    <URIString>http://vue.tufts.edu/rdf/resource/4fe858eb10b3d16600b3589d65a9470a</URIString>
                    <shape xsi:type="rectangle"/>
                </textStyle>
                <linkStyle ID="5" label="Links" created="1440153806416"
                    x="373.5" y="384.0" width="53.0" height="32.0"
                    strokeWidth="0.0" autoSized="true" isStyle="true" xsi:type="node">
                    <strokeColor>#404040</strokeColor>
                    <textColor>#B3BFE3</textColor>
                    <font>Gill Sans-plain-18</font>
                    <URIString>http://vue.tufts.edu/rdf/resource/4fe858ec10b3d16600b3589d7a9416c7</URIString>
                    <shape xsi:type="rectangle"/>
                </linkStyle>
            </masterSlide>
        </pathway>
    </PathwayList>
    <date>2015-08-21</date>
    <modelVersion>6</modelVersion>
    <saveLocation>C:\Users\siamitku\Documents\VUE</saveLocation>
    <saveFile>C:\Users\siamitku\Documents\VUE\mentor.vue</saveFile>
</LW-MAP>
